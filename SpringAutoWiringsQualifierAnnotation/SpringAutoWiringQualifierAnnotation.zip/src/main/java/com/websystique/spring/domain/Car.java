package com.websystique.spring.domain;

public interface Car {

	public void getCarName();

}
