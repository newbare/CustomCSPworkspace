package com.websystique.spring.service;

import org.joda.time.LocalDate;

public interface DateService {

	LocalDate getNextAssessmentDate();
}
