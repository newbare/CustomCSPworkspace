package com.websystique.spring.dao;

import com.websystique.spring.model.Employee;

public interface EmployeeDao {

	void saveInDatabase(Employee employee);
}
