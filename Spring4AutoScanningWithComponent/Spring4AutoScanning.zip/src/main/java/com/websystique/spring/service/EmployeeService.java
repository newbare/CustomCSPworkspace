package com.websystique.spring.service;

import com.websystique.spring.model.Employee;

public interface EmployeeService {

	void registerEmployee(Employee employee);
}

