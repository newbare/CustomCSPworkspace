package com.websystique.spring.service;

public interface FileService {

	void readValues();
}
